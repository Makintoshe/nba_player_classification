import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


def getParams(GP,MIN,PTS,FGM,FGA,FGP,PM,PA,PAP,FTM,FTA,FTP,OREB,DREB,REB,AST,STL,BLK,TOV):
    arr = np.array([[GP, MIN, PTS, FGM, FGA, FGP, PM, PA, PAP, FTM, FTA, FTP, OREB, DREB, REB, AST, STL, BLK, TOV]])
    #df = pd.DataFrame({"GP":GP,"MIN":MIN,"PTS":PTS,"FGM":FGM,"FGA":FGA,"FG%":FGP,"3P Made":PM,"3PA":PA,"3P%":PAP,"FTM":FTM,"FTA":FTA,"FT%":FTP,"OREB":OREB,"DREB":DREB,"REB":REB,"AST":AST,"STL":STL,"BLK":BLK,"TOV":TOV})
    return arr#df


def dataPreprocessing(arr):
    
    # extract names, labels, features names and values
    print(" notre array : ",np.array(arr))

    # replacing Nan values (only present when no 3 points attempts have been performed by a player)
    #for x in np.argwhere(np.isnan(df_vals)):
    #    df_vals[x] = 0.0

    # (data - min) / max - min
    # arr = np.array(arr)

    minimum, maximum = minmax(arr)

    #minimum = float(min(min(arr)))
    print("min ::: ",minimum)

    #maximum = float(max(max(arr)))
    print("max ::: ",maximum)

    den = maximum - minimum

    vector = np.vectorize(np.float)
    arr = vector(arr)
    vect = []

    for i in range(len(arr)):
        vect.append((arr[i] - minimum) / den)

    model = pickle.load(open('static/data/classifier.pikl', 'rb'))

    prediction = model.predict(vect)

    data = pd.DataFrame({"decision":prediction, "data_normalized":vect})
    data = data.to_json()

    return data

def minmax(arr):
    minimum = float(arr[0][0])
    maximum = float(arr[0][0])
    for i in range(len(arr[0])):
        val = float(arr[0][i])
        if minimum>val:
            minimum=val
        if maximum<val:
            maximum=val
    return minimum, maximum


def getPredictByName_fromCSV(Name_):
    df = pd.read_csv("static/data/nba_logreg.csv")

    # extract names, labels, features names and values
    names = df['Name'].values.tolist()  # players names
    labels = df['TARGET_5Yrs'].values  # labels
    paramset = df.drop(['TARGET_5Yrs', 'Name'], axis=1).columns.values
    df_vals = df.drop(['TARGET_5Yrs', 'Name'], axis=1).values

    # replacing Nan values (only present when no 3 points attempts have been performed by a player)
    for x in np.argwhere(np.isnan(df_vals)):
        df_vals[x] = 0.0

    # normalize dataset
    X = MinMaxScaler().fit_transform(df_vals)

    model = pickle.load(open('static/data/classifier.pikl', 'rb'))
    res = model.predict(X)

    res_frame = pd.DataFrame({'names': names, 'prediction': res})

    pred = res_frame[res_frame['names']==Name_]
    value_pred = pred['prediction'].values

    data = pd.DataFrame({"decision": value_pred})
    data = data.to_json()

    return data
