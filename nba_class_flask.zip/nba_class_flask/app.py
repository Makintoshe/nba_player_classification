from flask import Flask, request, jsonify

from flask_cors import CORS #gestion des accès au w.s.

from functions import getParams, dataPreprocessing, getPredictByName_fromCSV #appeler la méthode qui récupère les params à traiter.


app = Flask(__name__)

CORS(app, resources={r"/api/nba/*": {"origins": "*"}})

@app.route('/')
def start_server():
    return 'Le serveur NBA prediction by MP DATA a démarré!'


@app.route('/api/nba/predict')
def playerParams():
    GP = request.args.get('GP')
    MIN = request.args.get('MIN')
    PTS = request.args.get('PTS')
    FGM = request.args.get('FGM')
    FGA = request.args.get('FGA')
    FGP = request.args.get('FGP')
    PM = request.args.get('PM')
    PA = request.args.get('PA')
    PAP = request.args.get('PAP')
    FTM = request.args.get('FTM')
    FTA = request.args.get('FTA')
    FTP = request.args.get('FTP')
    OREB = request.args.get('OREB')
    DREB = request.args.get('DREB')
    REB = request.args.get('REB')
    AST = request.args.get('AST')
    STL = request.args.get('STL')
    BLK = request.args.get('BLK')
    TOV = request.args.get('TOV')

    data_arr = getParams(GP,MIN,PTS,FGM,FGA,FGP,PM,PA,PAP,FTM,FTA,FTP,OREB,DREB,REB,AST,STL,BLK,TOV)

    data = dataPreprocessing(data_arr)

    return data


@app.route('/api/nba/info')
def decision_by_name():
    Name_ = request.args.get('Name')
    data = getPredictByName_fromCSV(Name_)

    return data



@app.route('/api/nba/dataset')
def dataset_classification():
    fic = request.args.get('fic')

    return "prêt à faire de la classification pour le dataset"



if __name__ == '__main__':
    app.run()
