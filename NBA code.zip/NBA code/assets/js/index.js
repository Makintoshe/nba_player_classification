/*******************************LISTENER*******************************/

document.getElementById("btn_getparams").addEventListener("click", getParams); //19 params
document.getElementById("btn_getdecisionbyname").addEventListener("click", getDecisionById);
document.getElementById("btn_getficclassification").addEventListener("click", getFilClassification);

/***************VAR GET DECISION & GET DECISION OF A NAME *************/

function getDecisionById() {

  NameOfPlayer=document.getElementById("NameOfPlayer").value

  var Decisions_by_name = {
    "url": "http://localhost:8080/api/nba/info?Name="+NameOfPlayer,
    "method": "GET",
    "timeout": 0,
  };

  // on execute notre requête HTTP et, on attend notre réponse à l'aide d'une promesse (une fonction qui attend une valeur).
  $.ajax(Decisions_by_name).done(function (response) {
    //console.log(response);

    txt = document.getElementById("txt")
  
    myJSON = response; 
    myObj = JSON.parse(myJSON); // from json data to js Object
    
    x = myObj.decision[0]; // récupère la valeur prédite
  
    if (x==1.0){
      txt.style.color = "green";
      txt.innerHTML= "Vous pouvez recruter!";
    }else{
      txt.style.color = "red";
      txt.innerHTML = "Vous ne devez pas recruter!";
    }    

  });
}


/***************VARs GET Params & GET DECISION OF Params*******************/

function getParams() {

  TOV=document.getElementById("TOV").value
  GP=document.getElementById("GP").value
  MIN=document.getElementById("MIN").value
  PTS=document.getElementById("PTS").value
  FGM=document.getElementById("FGM").value
  FGA=document.getElementById("FGA").value
  FGP=document.getElementById("FGP").value
  PM=document.getElementById("PM").value
  PA=document.getElementById("PA").value
  PAP=document.getElementById("PAP").value
  FTM=document.getElementById("FTM").value
  FTA=document.getElementById("FTA").value
  FTP=document.getElementById("FTP").value
  OREB=document.getElementById("OREB").value
  DREB=document.getElementById("DREB").value
  REB=document.getElementById("REB").value
  AST=document.getElementById("AST").value
  STL=document.getElementById("STL").value
  BLK=document.getElementById("BLK").value

  var Player_params = {
    "url": "http://localhost:8080/api/nba/predict?TOV="+TOV+"&GP="+GP+"&MIN="+MIN+"&PTS="+PTS+"&FGM="+FGM+"&FGA="+FGA+"&FGP="+FGP+"&PM="+PM+"&PA="+PA+"&PAP="+PAP+"&FTM="+FTM+"&FTA="+FTA+"&FTP="+FTP+"&OREB="+OREB+"&DREB="+DREB+"&REB="+REB+"&AST="+AST+"&STL="+STL+"&BLK="+BLK,
    "method": "GET",
    "timeout": 0,
  };
  
  $.ajax(Player_params).done(function (response) {   

  txt = document.getElementById("txt")
  
  myJSON = response; 
  myObj = JSON.parse(myJSON); // from json data to js Object
  
  x = myObj.decision[0]; // récupère la valeur prédite

  if (x==1.0){
    txt.style.color = "green";
    txt.innerHTML= "Vous pouvez recruter!";
  }else{
    txt.style.color = "red";
    txt.innerHTML = "Vous ne devez pas recruter!";
  }
  });
  //
}


/************************FILE DATASET***********************/
function getFilClassification() {

  fic ="" //chemin absolu ou relatif vers la source de données

  var dataset_fic = {
    "url": "http://localhost:8080/api/nba/dataset?fic="+fic,
    "method": "GET",
    "timeout": 0,
  };
  
  $.ajax(dataset_fic).done(function (response) {

    txt = document.getElementById("txt")

    myJSON = response;
    myObj = JSON.parse(myJSON);

    x = myObj.decision[0];
    
    if (x==1.0){
      txt.style.color = "green";
      txt.innerHTML= "Vous pouvez recruter!";
    }else{
      txt.style.color = "red";
      txt.innerHTML = "Vous ne devez pas recruter!";
    }

  });

}